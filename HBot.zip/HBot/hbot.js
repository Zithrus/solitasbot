const Discord = require("discord.js");
const bot     = new Discord.Client({fetchAllMembers: true});
const fs      = require("fs");
const moment  = require("moment");
const actsecs = 5;

var settings  = './settingsConfig/settings.json';
var file = require(settings)

var TOKEN = file.TOKEN;

const log = (msg) => {
  console.log(`[${moment().format("YYYY-MM-DD HH:mm:ss")}] ${msg}`);
};

bot.commands = new Discord.Collection();
bot.aliases = new Discord.Collection();
fs.readdir("./cmd/", (err, files) => {
  if (err) console.error(err);
  log(`Loading a total of ${files.length} commands.`);
  files.forEach(f => {
    let props = require(`./cmd/${f}`);
    log(`Loading Command: ${props.help.name}`);
    bot.commands.set(props.help.name, props);
    props.conf.aliases.forEach(alias => {
      bot.aliases.set(alias, props.help.name);
    });
  });
});

bot.on("guildMemberAdd", function(member) {
  member.addRole(member.guild.roles.find("name", "Members")).then(() => {
  })
});

bot.on("message", msg => {

  var prefix = "hb>";

  if (msg.author.bot) return;
  if (!msg.content.startsWith(prefix)) return;
  if (msg.channel.type == "dm") return;

  let command = msg.content.split(" ")[0].slice(prefix.length);
  let params = msg.content.split(" ").slice(1);
  let perms = bot.elevation(msg);
  let cmd;

  if (bot.commands.has(command)) {
    cmd = bot.commands.get(command);
  } else if (bot.aliases.has(command)) {
    cmd = bot.commands.get(bot.aliases.get(command));
  }
  if (cmd) {
    if (perms < cmd.conf.permLevel) return msg.channel.send("Oops looks like you dont have the right permission level :(");
    cmd.run(bot, msg, params, perms, prefix);
  }
});

bot.on("ready", () => {
  log(`Ready to serve ${bot.users.size} users, in ${bot.channels.size} channels of ${bot.guilds.size} servers.`);
  setTimeout(setAct, actsecs * 1000)
});

  function setAct() {
  	 setTimeout(act1, 5000);
  	 setTimeout(act2, 20000);
  	 setTimeout(act3, 40000);
  	 setTimeout(act4, 60000);
  	 setTimeout(setAct, 80000);
  }
  
  function act1() {
  bot.user.setActivity("hb>help | treehousemc was here :D", {type: "PLAYING"});
  }
  
  function act2() {
  	  bot.user.setActivity("hb>help | mc.happype.us.to:19132", {type: "PLAYING"});
  }
  
  function act3() {
  	  bot.user.setActivity("hb>help | Sonsa Knows", {type: "PLAYING"});
  }
  function act4() {
  	  bot.user.setActivity("hb>help | HappyBedrock #1", {type: "PLAYING"});
  }

bot.on("error", console.error);
bot.on("warn", console.warn);

bot.login(TOKEN);

bot.on('disconnect', function(erMsg, code) {
  console.log('----- Bot disconnected from Discord with code', code, 'for reason:', erMsg, '-----');
  bot.connect(TOKEN);
});

bot.reload = function (command) {
  return new Promise((resolve, reject) => {
    try {
      delete require.cache[require.resolve(`./cmd/${command}`)];
      let cmd = require(`./cmd/${command}`);
      bot.commands.delete(command);
      bot.aliases.forEach((cmd, alias) => {
        if (cmd === command) bot.aliases.delete(alias);
      });

      bot.commands.set(command, cmd);
      cmd.conf.aliases.forEach(alias => {
        bot.aliases.set(alias, cmd.help.name);
      });
      resolve();
    } catch (e) {
      reject(e);
    }
  });
};

bot.elevation = function (msg) {
  /* This function should resolve to an ELEVATION level which
     is then sent to the command handler for verification*/
  let permlvl = 0;

  let mod_role = msg.guild.roles.find("name", "💼 Discord Helper");
  if (mod_role && msg.member.roles.has(mod_role.id)) permlvl = 2;
  
   let staff_role = msg.guild.roles.find("name", "💼 Server Mod");
  if (staff_role && msg.member.roles.has(staff_role.id)) permlvl = 2;

  let dcm_role = msg.guild.roles.find("name", "👨‍💼 Discord Manager");
  if (dcm_role && msg.member.roles.has(dcm_role.id)) permlvl = 3;
  
  let admin_role = msg.guild.roles.find("name", "👨‍💼 Server Admin");
  if (admin_role && msg.member.roles.has(admin_role.id)) permlvl = 3;
  
  let dev_role = msg.guild.roles.find("name", "👨‍💼 Server Developer");
  if (dev_role && msg.member.roles.has(dev_role.id)) permlvl = 3;
  
  let owner_role = msg.guild.roles.find("name", "HappyBedrock");
  if (owner_role && msg.member.roles.has(owner_role.id)) permlvl = 4;

  if (msg.author.id === "472338189697286155") permlvl = 4;
  return permlvl;
};