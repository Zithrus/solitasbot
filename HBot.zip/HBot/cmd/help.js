exports.run = (bot, message, args, perms, prefix) => {
    if (!args[0]) {
      message.author.send(`= Command List =\n\n[Use ${prefix}help <commandname> for details]\n\n${bot.commands.map(c=>`${c.help.name} - ${c.help.description}`).join("\n")}`, {code: "asciidoc"});
      message.reply("I sent you a full list of commands you can run");
      
  } else {
    let command = args[0];
    if(bot.commands.has(command)) {
      command = bot.commands.get(command);
      message.author.send(`= ${command.help.name} = \n${command.help.description}\nusage - ${command.help.usage}`, {code: "asciidoc"});
      message.reply(`Details about ${command.help.name} has been sent via DM!`);
    }
  }
};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ["cmdinfo"],
  permLevel: 0
};

exports.help = {
  name : "help",
  description: "Returns pages of commands.",
  usage: "help [command]"
};