const Discord = require("discord.js");
const errors = require("../utils/errors.js");

module.exports.run = (bot, message, args) => {

    if(!message.member.hasPermission("KICK_MEMBERS")) return errors.noPerms(message, "KICK_MEMBERS");
    if(args[0] == "help"){
      message.reply("Usage: !kick <user> <reason>");
      return;
    }
    let kUser = message.guild.member(message.mentions.users.first() || message.guild.members.get(args[0]));
    if(!kUser) return errors.cantfindUser(message.channel);
    let kReason = args.join(" ").slice(22);
    if(kUser.hasPermission("MANAGE_MESSAGES")) return errors.equalPerms(message, kUser, "MANAGE_MESSAGES");

    let kickEmbed = new Discord.RichEmbed()
    .setDescription("~Kick~")
    .setColor("#e56b00")
    .addField("Kicked User", `${kUser} with ID ${kUser.id}`)
    .addField("Kicked By", `<@${message.author.id}> with ID ${message.author.id}`)
    .addField("Kicked In", message.channel)
    .addField("Tiime", message.createdAt)
    .addField("Reason", kReason);

    let kickChannel = message.guild.channels.find(`name`, "mod-logs");
    if(!kickChannel) return message.channel.send("Can't find mod-logs channel.");

    message.guild.member(kUser).kick(kReason);
    kickChannel.send(kickEmbed);
    message.channel.send(kickEmbed);
}

module.exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ["k"],
  permLevel: 2
};

module.exports.help = {
  name: "kick",
  description: "Kick a user from the server.",
  usage: "kick [USER] [REASON]"
};