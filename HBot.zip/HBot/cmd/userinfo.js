const Discord = require('discord.js');

module.exports.run = (bot, message, args) => {
	let user = message.mentions.users.first() || message.author;
	let embed = new Discord.RichEmbed()
	.setAuthor(`${user.username}'s Info`, user.displayAvatarURL)
	.setThumbnail(user.displayAvatarURL)
	.setColor('RANDOM')
	.addField('Username', user.username, true)
	.addField('Discriminator', user.discriminator, true)
	.addField('Status', user.presence.status, true)
	.addField('Bot?', user.bot, true)
	.setThumbnail(user.displayAvatarURL)
	message.channel.send(embed);
};

module.exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ["uinfo"],
  permLevel: 0
};

module.exports.help = {
  name: "userinfo",
  description: "Gets an info about someone",
  usage: "userinfo [USER]"
};