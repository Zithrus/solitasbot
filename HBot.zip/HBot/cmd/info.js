const Discord = require("discord.js");

 module.exports.run = (bot, message, args) => {
 	
 	const embed = new Discord.RichEmbed()
 	.setTitle("Information")
 	.setColor("RANDOM")
 	.addField("Website", "http://mc.happype.us.to")
 	.addField("Discord", "https://discord.gg/RvgBywr")
 	.addField("IP", "mc.happype.us.to")
 	.addField("Port", "19132")
 	.addField("What do we have?", "Skywars, Bedwars, UHC, Duels, FFA, Zombie Mode, etc.");
 	
 	message.channel.send(embed);
 	
}

module.exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ["ip"],
  permLevel: 0
};

module.exports.help = {
  name: "info",
  description: "Gathers informations about the server IP and Port",
  usage: "info"
};