const Discord = require("discord.js");
const botconfig = require("../botconfig.json");

module.exports.run = (bot, message, args) => {
    const useruser = "Command Ran By: " + message.author.username;
    const userurl = message.author.avatarURL;
    let botembed = new Discord.RichEmbed()
        .setColor(botconfig.red)
        .setDescription(`Loading...`)
        .setTimestamp()
    message.channel.send(botembed).then(message =>{
        botembed.setColor(botconfig.lightblue)
        botembed.setDescription(`:ping_pong: Pong! **\`${bot.pings[0]}ms\`**`)
        botembed.setFooter(useruser, userurl)
        botembed.setTimestamp()
        message.edit(botembed)
    })

}

module.exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ["ms"],
  permLevel: 0
};

module.exports.help = {
  name: "ping",
  description: "Pings the bot Gateway.",
  usage: "ping"
};