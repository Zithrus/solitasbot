const Discord = require("discord.js");

exports.run = (bot, message, args) => {
  let mbed = new Discord.RichEmbed()
  .setColor("#1b1ece")
  .addField("Servers", `I am currently serving ${bot.users.size} users, in ${bot.channels.size} channels of ${bot.guilds.size} servers.`);
  
  message.channel.send(mbed);
};

exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [],
  permLevel: 0
};

exports.help = {
  name: "servers",
  description: "Get the count of servers the bot is in.",
  usage: "servers"
};