const Discord = require('discord.js');

module.exports.run = (bot, message, args) => {

  ROLEZZ = message.guild.roles.array()
  
  var ROLES = "";

    ROLEZZ.forEach(function(element){
        ROLES += element.name + "\n"
    });
    
    message.channel.send("```" + "\n" +
                         "---------------------------------" + "\n" +
                         "ALL SERVER ROLES" + "\n" +
                         "---------------------------------" + "\n" +
                         `${ROLES}` + "```");

}

module.exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ["getroles"],
  permLevel: 0
};

module.exports.help = {
  name: "roles",
  description: "Get all the server roles.",
  usage: "roles"
};