const figlet = require('figlet');

module.exports.run = (bot, message, args) => {
	if (!args.join(' ')) return message.channel.send('Please provide text');
	figlet(args.join(' '), (err, data) => {
		message.channel.send(data, {
			code: 'ascii'
		});
	});
};

module.exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ["asc"],
  permLevel: 0
};

module.exports.help = {
  name: "ascii",
  description: "Turns a text into ascii.",
  usage: "ascii [TEXT]"
};