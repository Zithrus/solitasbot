const Discord = require("discord.js");

module.exports.run = (bot, message, args) => {
	
	if (!args[0]) return message.channel.send("Proper Usage: hb>poll [QUESTION]");
	
	const emb = new Discord.RichEmbed()
	.setColor("#000F0")
	.setTitle("React to Vote.")
	.setDescription(args.join(' '))
	.setFooter(`Poll Created By ${message.author.username}`)
	
	message.delete()
	message.channel.send(emb).then(emsg => {
		
		emsg.react('✅')
		emsg.react('❎')
	});
}

module.exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ["ask"],
  permLevel: 3
};

module.exports.help = {
  name: "poll",
  description: "Create a poll for the members to vote",
  usage: "poll [QUESTION]"
};