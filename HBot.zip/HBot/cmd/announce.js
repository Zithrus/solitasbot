const Discord = require("discord.js");

module.exports.run = (bot, message, args) => {
	let title = args[0];
	let text = args.slice(1).join(" ");
	let anchannel = message.guild.channels.find(`name`, "announcement");
	if (!title) return message.channel.send("Proper Usage: hb>announce [TITLE] [ANNOUNCEMENT]").then(msg => {msg.delete(5000)});
	if (!text) return message.channel.send("Please mention what you are announcing.").then(msg => {msg.delete(5000)});
	if (!anchannel) return message.channel.send("Can't find a channel named #announcement").then(msg => {msg.delete(5000)});
	
	let aembed = new Discord.RichEmbed()
	.setColor("#00ff26")
	.setTitle(title)
	.setDescription(text)
	.setFooter(`Announcement published by ${message.author.username}`);
	
	anchannel.send(aembed);
	message.channel.send("Announcement have been sent").then(msg => {msg.delete(5000)});
}

module.exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: [],
  permLevel: 3
};

module.exports.help = {
  name: "announce",
  description: "Announce some updates about the server.",
  usage: "announce [TITLE] [ANNOUNCEMENT]"
};