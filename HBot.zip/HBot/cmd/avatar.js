const Discord = require('discord.js');

module.exports.run = (bot, message, args) => {
	let user = message.mentions.users.first() || message.author;
	let embed = new Discord.RichEmbed()
	.setAuthor(`${user.username}'s Avatar`)
	.setImage(user.displayAvatarURL)
	.setColor('RANDOM')
	message.channel.send(embed);
};

module.exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ["pfp"],
  permLevel: 0
};

module.exports.help = {
  name: "avatar",
  description: "Gets your's or someone's profile picture.",
  usage: "avatar [USER]"
};