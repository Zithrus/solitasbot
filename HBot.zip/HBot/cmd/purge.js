const Discord = require("discord.js");

module.exports.run = (bot, message, args) => {
	
	if(!message.member.hasPermission("MANAGE_MESSAGES")) return message.channel.send("You do not have permissions to use this command.");
	if(!args[0]) return message.channel.send("Usage: !purge <int>");
	message.channel.bulkDelete(args[0]).then(() => {
		message.channel.send(`Cleared ${args[0]} msssages.`).then(msg => msg.delete(2000));
	});
}

module.exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ["prune", "clear"],
  permLevel: 2
};

module.exports.help = {
  name: "purge",
  description: "Clear a specific ammount of messagss",
  usage: "purge [AMT]"
};