const Discord = require("discord.js");

module.exports.run = (bot, message, args) => {
	
	
	if(!args[2]) return message.reply("Please specify a question.");
	let replies = ["Yes.", "No.", "I don't know.", "Ask again later", "Please repeat your question", "It's up to you.", "Ask someone else.", "Yep", "Nope", "My sources say no", "Without a doubt", "Don't count on it", "My sources say yes"];
	
	let result = Math.floor((Math.random() * replies.length));
	let question = args.slice(0).join(" ");
	
	let ballembed = new Discord.RichEmbed()
	.setAuthor(message.author.tag)
	.setColor("#FF9900")
	.addField("Question", question)
	.addField("Answer", replies[result]);
	
	message.channel.send(ballembed);
	
	
}

module.exports.conf = {
  enabled: true,
  guildOnly: false,
  aliases: ["8b"],
  permLevel: 0
};

module.exports.help = {
  name: "8ball",
  description: "Ask the bot a specific question.",
  usage: "8ball [QUESTION]"
};